import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-previewform',
  templateUrl: './previewform.component.html',
  styleUrls: ['./previewform.component.css']
})
export class PreviewformComponent implements OnInit {
  pdfSrcq: string = '../assets/images/Photographer NOC.pdf';
  constructor(public router: Router) {

   }

  ngOnInit() {
  }



  



goto_closeprevw()
{
  this.router.navigate(['Onlineforms']);
  window.scrollTo(0, 0);
}
}