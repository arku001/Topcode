import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-task',
  templateUrl: './pending-task.component.html',
  styleUrls: ['./pending-task.component.css']
})
export class PendingTaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  slideConfig = {"slidesToShow": 1, "slidesToScroll": 1, "focusOnSelect":true, "dots":true};
}
