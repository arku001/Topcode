import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-declineoffer',
  templateUrl: './declineoffer.component.html',
  styleUrls: ['./declineoffer.component.css']
})
export class DeclineofferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
