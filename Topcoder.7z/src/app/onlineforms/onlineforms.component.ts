import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {MatDialog} from '@angular/material';

@Component({
  selector: 'app-onlineforms',
  templateUrl: './onlineforms.component.html',
  styleUrls: ['./onlineforms.component.css']
})
export class OnlineformsComponent implements OnInit {

  constructor(public router: Router, public dialog:MatDialog) {
  }
 
  ngOnInit() {
  }


  open_guildelines() {
    window.scrollTo(0, 0);
    this.dialog.open(guildelinescomponent, {
    width: '924px',
    height:'100px'
  });
}
homepage()
{
  window.scroll(0, 0);
}

  goto_savepreview()
{
  this.router.navigate(['Previewform']);
  window.scrollTo(0, 0);
}
}


@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './guildelines.html'
})
export class guildelinescomponent {
   first=true;
   second=false;
  editjoin(){
    this.first=false;
    this.second=true;
 
  }
}
