import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobbasketComponent } from './jobbasket.component';

describe('JobbasketComponent', () => {
  let component: JobbasketComponent;
  let fixture: ComponentFixture<JobbasketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobbasketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobbasketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
