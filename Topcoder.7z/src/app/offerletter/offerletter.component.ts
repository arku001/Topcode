import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
import { FileUploader } from 'ng2-file-upload';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-offerletter',
  templateUrl: './offerletter.component.html',
  styleUrls: ['./offerletter.component.css']
})

export class OfferletterComponent implements OnInit {
  public notenable=true;
  public enableTab=false;
  public accept= true;
  
  constructor(public dialog:MatDialog, public router: Router) {
    
   }

  ngOnInit() {
   // document.getElementById('acceptedstatus').style.display="none";
   //document.getElementById('acceptedstatus').innerHTML="dd";
  }



  openDeclarationPop_new() {
    
    this.dialog.open(DeclarationModalNewsComponent1, {
    width: '500px',
    height:'100px'
  });
}
openDeclarationPop_new3() {
  
  this.dialog.open(DeclarationModalNewsComponent3, {
  width: '500px',
  height:'100px'
});
}

applynw() {
   
  this.dialog.open(applynwComponent, {
  width: '400px',
  height:'200px'
});
}



}


@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './declarationPopupnews.html'
})
export class DeclarationModalNewsComponent1 {
  
  first=true;
  second=false;

  editjoin(){
    window.scrollTo(300, 500);
    this.first=false;
    this.second=true;
 
  }
}

@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './declarationPopupnews3.html'
})
export class DeclarationModalNewsComponent3 {
   first=true;
   second=false;
  editjoin(){
    this.first=false;
    this.second=true;
 
  }
  declineOk()
  {
    alert("Decline");
    //this.test=true;
  }
}


@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './applynw.html'
})
export class applynwComponent {

  public router: Router;
  topScreen(){
    // alert("top");
    window.scrollTo(0, 0);
    //this.router.navigate(['acceptoff']);
    // window.scrollTo(0, 0);
  }
  acceptoffer(){
  // document.getElementById('test').innerHTML='<div class="col-xs-12 col-lg-12 col-sm-12 col-md-12 no_pad address_notdf">'+
  // +'<div class="col-xs-12 col-lg-12 col-sm-12 col-md-12 no_pad sel">'+
  // +'<div class="pull-left red_circle">'+
  // +' <span class="pull-left col-xs-12 no_pad icon-close info_icn"></span>'+
  // +'</div> <div class="col-xs-11 col-lg-11 col-sm-11 col-md-11 no_pad Please-Note-By-you_first fntwgt mrgn_lft15">'+
  // +'  Your have declined the offer dated on 23, Jan,2017 &nbsp; | &nbsp; 04:50:00PM'+
  // +'</div>  </div></div>';

  //document.getElementById('test').style.visibility = "hidden";
  // document.getElementById('acceptedstatus').style.display="none";
    // this.acceptvalue =true;
     
  }
}