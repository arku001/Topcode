import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';

@Component({
  selector: 'app-offer',
  templateUrl: './offer.component.html',
  styleUrls: ['./offer.component.css']
})
export class OfferComponent implements OnInit {

  constructor(public dialog:MatDialog) { }
 offer_container = true;
 offer_second = false;

  ngOnInit() {
  }


  openAddressSubmitPop() {
    this.dialog.open(AddressSubmitPopComponent12, {
  });
}


 openaccept()
  {
    this.offer_container=false;
    this.offer_second = true;
 }

}
@Component({
  selector: 'app-addrSubmitModal',
  templateUrl: './addalert.html'
  })
  export class AddressSubmitPopComponent12 {
  }