import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';

@Component({
  selector: 'app-interview-schedule',
  templateUrl: './interview-schedule.component.html',
  styleUrls: ['./interview-schedule.component.css']
})
export class InterviewScheduleComponent implements OnInit {

  constructor(public dialog:MatDialog) { }

  ngOnInit() {
  }


  openAddressSubmitPop() {
    this.dialog.open(AddressSubmitPopComponent11, {
  });
}

}

@Component({
  selector: 'app-addrSubmitModal',
  templateUrl: './addalert.html'
  })
  export class AddressSubmitPopComponent11 {
  }