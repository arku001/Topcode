import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
// import { PerfectScrollbarConfigInterface,
//   PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';

@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent implements OnInit {

  

  constructor(public dialog:MatDialog) { }

  ngOnInit() {
  }
  desc=false;
  desce=false;
  desceg=false;
  requireddescri(){
    this.desc=true;
    
  }
  requireddescrip(){
    this.desce=true;
    
  }
  requireddescripg(){
    this.desceg=true;
    
  }
  onClickedOutside(Data){
    this.desc=false;
    
  }
  onClickedOutsidef(Data){
    this.desce=false;
    
  }
  onClickedOutsidefg(Data){
    this.desceg=false;
    
  }



}



