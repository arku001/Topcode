import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acceptoffer',
  templateUrl: './acceptoffer.component.html',
  styleUrls: ['./acceptoffer.component.css']
})
export class AcceptofferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
