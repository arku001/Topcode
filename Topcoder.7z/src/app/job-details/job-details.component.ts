import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
@Component({
  selector: 'app-job-details',
  templateUrl: './job-details.component.html',
  styleUrls: ['./job-details.component.css']
})
export class JobDetailsComponent implements OnInit {

  constructor(public dialog:MatDialog) { }

  ngOnInit() {
  }



applyrefer() {
  window.scrollTo(0, 0);
  this.dialog.open(applyreferComponent1, {
    
  width: '700px',
  height:'200px'
});
}

slideConfig = {"slidesToShow": 1, "slidesToScroll": 1, "focusOnSelect":true, "dots":true};
}


@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './applyrefer.html'
})
export class applyreferComponent1 {

}