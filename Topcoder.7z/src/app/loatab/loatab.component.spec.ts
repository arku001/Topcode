import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoatabComponent } from './loatab.component';

describe('LoatabComponent', () => {
  let component: LoatabComponent;
  let fixture: ComponentFixture<LoatabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoatabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoatabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
