import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editoffer',
  templateUrl: './editoffer.component.html',
  styleUrls: ['./editoffer.component.css']
})
export class EditofferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
