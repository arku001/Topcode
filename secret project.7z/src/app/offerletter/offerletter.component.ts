import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
import { FileUploader } from 'ng2-file-upload';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-offerletter',
  templateUrl: './offerletter.component.html',
  styleUrls: ['./offerletter.component.css']
})

export class OfferletterComponent implements OnInit {
  public notenable=true;
  public enableTab=false;
  public accept= true;
  
  constructor(public dialog:MatDialog, public router: Router) {
    
   }

  ngOnInit() {
   // document.getElementById('acceptedstatus').style.display="none";
   //document.getElementById('acceptedstatus').innerHTML="dd";
  }



  openDeclarationPop_new() {
    
    this.dialog.open(DeclarationModalNewsComponent1, {
    width: '500px',
    height:'100px'
  });
}
openDeclarationPop_new3() {
  
  this.dialog.open(DeclarationModalNewsComponent3, {
  width: '500px',
  height:'100px'
});
}

applynw() {
   
  this.dialog.open(applynwComponent, {
  width: '400px',
  height:'200px'
});
}



}


@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './declarationPopupnews.html'
})
export class DeclarationModalNewsComponent1 {
  
  first=true;
  second=false;

  editjoin(){
    window.scrollTo(300, 500);
    this.first=false;
    this.second=true;
 
  }
}

@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './declarationPopupnews3.html'
})
export class DeclarationModalNewsComponent3 {
   first=true;
   second=false;
  editjoin(){
    this.first=false;
    this.second=true;
 
  }
  declineOk()
  {
    alert("Decline");
    //this.test=true;
  }
}


@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './applynw.html'
})
export class applynwComponent {

  public router: Router;
  topScreen(){
    window.scrollTo(0, 0);}
  acceptoffer(){
     
  }
}