import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
@Component({
  selector: 'app-refer-details',
  templateUrl: './refer-details.component.html',
  styleUrls: ['./refer-details.component.css']
})
export class ReferDetailsComponent implements OnInit {

  constructor(public dialog:MatDialog) { }

  ngOnInit() {
  }
  applyrefer() {
    this.dialog.open(applyreferComponent, {
    width: '400px',
    height:'200px'
  });
}
  slideConfig = {"slidesToShow": 1, "slidesToScroll": 1, "focusOnSelect":true, "dots":true};

}
@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './applyrefer.html'
})
export class applyreferComponent {

}