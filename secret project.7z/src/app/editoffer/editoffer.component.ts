import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
@Component({
  selector: 'app-editoffer',
  templateUrl: './editoffer.component.html',
  styleUrls: ['./editoffer.component.css']
})
export class EditofferComponent implements OnInit {

   
  constructor(public dialog:MatDialog) {
  }

  ngOnInit() {
  }



  openDeclarationPop_new() {
    
    this.dialog.open(DeclarationModalNewsComponent8, {
    width: '500px',
    height:'100px'
  });
}





}







@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './declarationPopupnews.html'
})
export class DeclarationModalNewsComponent8 {
  
  first=true;
  second=false;

  editjoin(){
    window.scrollTo(300, 500);
    this.first=false;
    this.second=true;
 
  }
}




