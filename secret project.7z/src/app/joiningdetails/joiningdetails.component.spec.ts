import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JoiningdetailsComponent } from './joiningdetails.component';

describe('JoiningdetailsComponent', () => {
  let component: JoiningdetailsComponent;
  let fixture: ComponentFixture<JoiningdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JoiningdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JoiningdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
