import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';

var ss="A";
// let first:boolean;
// let second:boolean;
// var first=true;
// var second=false;

@Component({
  selector: 'app-joiningdetails',
  templateUrl: './joiningdetails.component.html',
  styleUrls: ['./joiningdetails.component.css']
})


export class JoiningdetailsComponent implements OnInit {

  
  constructor(public dialog:MatDialog) { }

  ngOnInit() {
  }


  openDeclarationPop_new() {
    
    this.dialog.open(DeclarationModalNewsComponent, {
    width: '500px',
    height:'100px'
  });
}

}

@Component({
  selector: 'app-declaration_newModal',
  templateUrl: './declarationPopupnews.html'
})
export class DeclarationModalNewsComponent {
   first=true;
   second=false;
  editjoin(){
    this.first=false;
    this.second=true;
 
  }
}
