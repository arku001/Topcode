import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  personal_details=true;
  address_details=false;
  eduaction_details=false;
  work_exp_details=false;
  loa_details=false;
  OtherInfo=false;
  public picuploads=true;
  public countp="6";
  public pending=true;
  constructor(public router : Router) { }
  // goto_homepage()
  // {
  //   this.router.navigate(['landing']);
  //   window.scrollTo(0, 0);
  // }
  rejectenbale(){
    this.pending=false;
  }

  picupload(){
    
    this.picuploads=false;
    console.log("picupload"+this.picupload);
  }


  Open_personal()
  {
    this.personal_details=true;
    this.address_details=false;
    this.eduaction_details=false;
    this.work_exp_details=false;
    this.loa_details=false;
    this.OtherInfo=false;
  }
  Open_Address()
  {    
    this.personal_details=false;
    this.address_details=true;
    this.eduaction_details=false;
    this.work_exp_details=false;
    this.loa_details=false;
    this.OtherInfo=false;
  }
  Open_Education()
  {
    this.personal_details=false;
    this.address_details=false;
    this.eduaction_details=true;
    this.work_exp_details=false;
    this.loa_details=false;
    this.OtherInfo=false;
  }
  Open_WorkExp()
  {
    this.personal_details=false;
    this.address_details=false;
    this.eduaction_details=false;
    this.work_exp_details=true;
    this.loa_details=false;
    this.OtherInfo=false;
  }
  Open_LOA()
  {
    this.personal_details=false;
    this.address_details=false;
    this.eduaction_details=false;
    this.work_exp_details=false;
    this.loa_details=true;
    this.OtherInfo=false;
  }
  Open_otherinfo()
  {
    this.personal_details=false;
    this.address_details=false;
    this.eduaction_details=false;
    this.work_exp_details=false;
    this.loa_details=false;
    this.OtherInfo=true;
  }
  ngOnInit() {
  }

}
