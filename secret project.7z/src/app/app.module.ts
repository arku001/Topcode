import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FileUploadModule } from 'ng2-file-upload';
import { SlickModule } from 'ngx-slick';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import 'hammerjs';
import { Observable, Subscription } from 'rxjs';
import { APP_BASE_HREF } from '@angular/common';
import { ClickOutsideModule } from 'ng-click-outside';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { AppComponent } from './app.component';
// import { PdfViewerModule } from 'ng2-pdf-viewer';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatStepperModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,

} from '@angular/material';

import { HeaderComponent, ChangePasswordComponent, ReferalComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LandingComponent } from './landing/landing.component';
import { ProfileComponent } from './profile/profile.component';
import { PersonalInfoComponent} from './personal-info/personal-info.component';


import { OfferComponent, AddressSubmitPopComponent12 } from './offer/offer.component';
import { PendingTaskComponent } from './pending-task/pending-task.component';
import { JobDetailsComponent, applyreferComponent1 } from './job-details/job-details.component';
import { JobbasketComponent } from './jobbasket/jobbasket.component';
import { LoatabComponent } from './loatab/loatab.component';
import { ReferDetailsComponent, applyreferComponent } from './refer-details/refer-details.component';
import { OnlineformsComponent, guildelinescomponent } from './onlineforms/onlineforms.component';
import { JoiningdetailsComponent,DeclarationModalNewsComponent } from './joiningdetails/joiningdetails.component';
import { OfferletterComponent,DeclarationModalNewsComponent1,DeclarationModalNewsComponent3,applynwComponent } from './offerletter/offerletter.component';
import { PreviewformComponent } from './previewform/previewform.component';
import { DeclineofferComponent } from './declineoffer/declineoffer.component';
import { AcceptofferComponent } from './acceptoffer/acceptoffer.component';
import { EditofferComponent,DeclarationModalNewsComponent8 } from './editoffer/editoffer.component';
import { InterviewScheduleComponent,AddressSubmitPopComponent11 } from './interview-schedule/interview-schedule.component';


const appRoutes: Routes = [
  { path: '', component: LandingComponent },
  { path: 'updateprofile', component: ProfileComponent },
  { path: 'pendingtask', component: PendingTaskComponent },
  { path: 'jobdetails', component: JobDetailsComponent },
  { path: 'jobbasket', component: JobbasketComponent },
  { path: 'ReferDetails', component: ReferDetailsComponent },
  { path: 'Onlineforms', component: OnlineformsComponent },
  { path: 'Joiningdetails', component: JoiningdetailsComponent },
  { path: 'Offerletter', component: OfferletterComponent },
  { path: 'Previewform', component: PreviewformComponent },
  { path: 'declineoff', component: DeclineofferComponent },
  { path: 'acceptoff', component: AcceptofferComponent },
  { path: 'editoffer', component: EditofferComponent },
];

@NgModule({
  declarations: [
    applyreferComponent,
    applyreferComponent1,
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LandingComponent,
    ProfileComponent,
    PersonalInfoComponent,
    AddressSubmitPopComponent12,
    ReferalComponent,
    ChangePasswordComponent,
    OfferComponent,
    PendingTaskComponent,
    JobDetailsComponent,
    JobbasketComponent,
    LoatabComponent,
    ReferDetailsComponent,
    OnlineformsComponent,
    JoiningdetailsComponent,
    DeclarationModalNewsComponent,
    DeclarationModalNewsComponent1,
    DeclarationModalNewsComponent3,
    DeclarationModalNewsComponent8,
    OfferletterComponent,
    applynwComponent,
    PreviewformComponent,
    guildelinescomponent,
    DeclineofferComponent,
    AcceptofferComponent,
    EditofferComponent,
    InterviewScheduleComponent,
    AddressSubmitPopComponent11
    
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatTabsModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    ClickOutsideModule,
    MatSelectModule,
    MatDialogModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatNativeDateModule,
    MatInputModule,
    MatExpansionModule,
    MatRadioModule,
    MatButtonModule,
    MatIconModule,
    ReactiveFormsModule,
    FormsModule,
    MatStepperModule,
    FileUploadModule,
    RouterModule.forRoot(appRoutes),
    SlickModule.forRoot(),
    PerfectScrollbarModule,
    // PdfViewerModule,

    
    NgCircleProgressModule.forRoot({
      backgroundStrokeWidth: 3,
      radius: 37,
      percent: 40,
      space: -4,
      maxPercent: 980,
      outerStrokeWidth: 6,
      outerStrokeColor: "#93f33a",
      innerStrokeColor: "#e7e8ea",
      innerStrokeWidth: 2,
      titleColor :" yellow",
      subtitleColor:"white",
      //  title: "10",
      "title": [
        "10",
      ],

      "subtitle":[
        "Days",
      ],


      titleFontSize: "50",
      subtitleFontSize: "24",
      animateTitle: false,
      animationDuration: 1000,
      showUnits: false,
      showBackground: false,
      startFromZero: false
    }),





  ],
  entryComponents: [ ReferalComponent,applynwComponent,DeclarationModalNewsComponent,DeclarationModalNewsComponent8,AddressSubmitPopComponent11,DeclarationModalNewsComponent1,DeclarationModalNewsComponent3, guildelinescomponent, applyreferComponent, applyreferComponent1,  AddressSubmitPopComponent12, ChangePasswordComponent
    //TermsAgreemntPopop,SelectedGiftsPopop,SkipFoodAlertPop,ReservationConfirmPop,MeetingDetSubConfPopup,ViewPasscodePopup,CancelMeetAlertPopup,RejectReasonPopup,DocumentsRequestPopup,SeekPopup,RejectPopup,ApprovePopup,AddGiftPop
  ],
  providers: [
    {
      provide: APP_BASE_HREF,
      useValue: '/embarkPreOffer'
    },
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
