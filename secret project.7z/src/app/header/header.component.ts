import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  notification:boolean=false;
  more:boolean=false;
  constructor(public dialog:MatDialog) { }

  ngOnInit() {
  }

  closeOptions(){
   
    this.more=false;
  }
  Notification()
  {
    this.notification=!this.notification;
    this.more= false;
  }
  More()
  {
    this.more=!this.more;
    this.notification= false;
  }
  openchngpasswrdpop() {
    this.dialog.open(ChangePasswordComponent, {
      width: '460px',
      height:'200px'
  });
  this.more= false;
}
openreferalpop() {
  this.dialog.open(ReferalComponent, {
});
this.more= false;
}
}
@Component({
  selector: 'app-changePasswordModal',
  templateUrl: './changepasswrd.html'
})
export class ChangePasswordComponent {
  desc=false;
  requireddescri(){
    this.desc=true;
    
  }
  onClickedOutside(Data){
    this.desc=false;
    
  }
}
@Component({
  selector: 'app-referalModal',
  templateUrl: './referal.html'
})
export class ReferalComponent {
}