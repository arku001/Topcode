import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})


export class LandingComponent implements OnInit {
  public imgsf = true;
  constructor(public router: Router) {

  }

  ngOnInit() {

  }



  expandFixedTable() {

    this.imgsf = false;
    console.log("this.imgsf" + this.imgsf);

  }
  closeHei() {

    this.imgsf = true;

  }



  onclick_closemanager() {

    this.imgsf = true;
    document.getElementsByClassName("expand_right")[0].classList.remove("active");
    setTimeout(function () {
      document.getElementsByClassName("expand_right")[0].classList.add("hidden");
    }, 100);
  }


  slideConfig = { "slidesToShow": 1, "slidesToScroll": 1, "focusOnSelect": true, "dots": true };
  goto_jobdetails() {
    this.router.navigate(['jobdetails']);
    window.scrollTo(0, 0);
  }
  goto_updateprofile() {
    this.router.navigate(['updateprofile']);
    window.scrollTo(0, 0);
  }
  goto_jobsapplied() {
    this.router.navigate(['jobsapplied']);
    window.scrollTo(0, 0);
  }
  goto_pendingtask() {
    this.router.navigate(['pendingtask']);
    window.scrollTo(0, 0);
  }
  goto_ReferDetails() {
    this.router.navigate(['ReferDetails']);
    window.scrollTo(0, 0);
  }
  goto_onlineforms() {
    this.router.navigate(['Onlineforms']);
    window.scrollTo(0, 0);
  }
  goto_Joiningdetails() {
    this.router.navigate(['Joiningdetails']);
    window.scrollTo(0, 0);
  }
  goto_Offerletter() {
    this.router.navigate(['Offerletter']);
    window.scrollTo(0, 0);
  }
}
