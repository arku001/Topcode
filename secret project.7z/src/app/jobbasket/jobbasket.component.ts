import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobbasket',
  templateUrl: './jobbasket.component.html',
  styleUrls: ['./jobbasket.component.css']
})
export class JobbasketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
