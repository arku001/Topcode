import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loatab',
  templateUrl: './loatab.component.html',
  styleUrls: ['./loatab.component.css']
})
export class LoatabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
