import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineformsComponent } from './onlineforms.component';

describe('OnlineformsComponent', () => {
  let component: OnlineformsComponent;
  let fixture: ComponentFixture<OnlineformsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineformsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineformsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
