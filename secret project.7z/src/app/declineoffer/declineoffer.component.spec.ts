import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeclineofferComponent } from './declineoffer.component';

describe('DeclineofferComponent', () => {
  let component: DeclineofferComponent;
  let fixture: ComponentFixture<DeclineofferComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeclineofferComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclineofferComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
